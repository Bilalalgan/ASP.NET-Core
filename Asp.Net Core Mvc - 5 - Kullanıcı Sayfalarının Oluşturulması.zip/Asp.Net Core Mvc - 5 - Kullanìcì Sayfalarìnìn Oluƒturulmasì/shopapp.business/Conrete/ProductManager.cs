using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using shopapp.business.Abstract;
using shopapp.dataaccess.Abstract;
using shopapp.dataaccess.Conrete.EfCore;
using shopapp.entity;

namespace shopapp.business.Conrete
{
    public class ProductManager : IProductService
    {
        private IProductRepository _productRepository;
        public ProductManager(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public void Create(Product entity)
        {
            //İş kuralları uygula
            _productRepository.Create(entity);
        }

        public void Delete(Product entity)
        {
            //İş kuralları uygula
            _productRepository.Delete(entity);
        }

        public List<Product> GetAll()
        {
            return _productRepository.GetAll();
        }

        public Product GetById(int id)
        {
            return _productRepository.GetById(id);
        }

        public int GetCountByCategory(string category)
        {
            return _productRepository.GetCountByCategory(category);
        }

        public List<Product> GetHomePageProducts()
        {
            return _productRepository.GetHomePageProducts();
        }

        public Product GetProductDetails(string producturl)
        {
            return _productRepository.GetProductDetails(producturl);
        }

        public List<Product> GetProductsByCategory(string name, int page, int pageSize)
        {
            return _productRepository.GetProductByCategory(name,page,pageSize);
        }

        public List<Product> GetSearchResult(string stringsearch)
        {
            return _productRepository.GetSearchResult(stringsearch);
        }

        public void Update(Product entity)
        {
            throw new NotImplementedException();
        }
    }
}