using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using shopapp.dataaccess.Abstract;
using shopapp.entity;

namespace shopapp.dataaccess.Conrete.EfCore
{
    public class EfCoreCategoryRepository : EfCoreGenericRepository<Category, ShopContext>, ICategoryRepository
    {
        public List<Category> GetPopularCategories()
        {
            throw new NotImplementedException();
        }
    }
}