using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using shopapp.entity;

namespace shopapp.dataaccess.Abstract
{
    public interface IProductRepository: IRepository<Product>
    {
        Product GetProductDetails(string producturl);
        List<Product> GetProductByCategory(string name, int page, int pageSize);
        List<Product> GetSearchResult(string search);
        List<Product> GetHomePageProducts();
        int GetCountByCategory(string category);
    }
}


