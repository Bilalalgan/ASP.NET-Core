using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using shopapp.entity;

namespace shopapp.webui.Models
{
    public class CategoryModel
    {
        public int CategoryId { get; set; }
        [Required(ErrorMessage ="Kategori adi zorunlu")]
        [StringLength(45,MinimumLength=5,ErrorMessage ="Kategori ismi 5-45 karakter.")]
        public string Name { get; set; }

        [StringLength(45,MinimumLength=5,ErrorMessage ="Kategori ismi 5-45 karakter.")]
        [Required(ErrorMessage ="Url zorunlu")]
        public string Url { get; set; }
        public List<Product> Products { get; set; }
    }
}


