using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace shopapp.webui.EmailServices
{
    public class SmtpEmailSender : IEmailSender
    {
        private string _host;        // SMTP sunucu adresi
        private int _port;            // SMTP sunucu portu
        private bool _enableSSL;      // SSL kullanılacak mı?
        private string _username;     // SMTP sunucu için kullanıcı adı
        private string _password;     // SMTP sunucu için şifre
        
        // Constructor ile SMTP sunucu bilgileri alınır.
        public SmtpEmailSender(string host, int port, bool enableSSL, string username, string password)
        {
            this._host = host;
            this._port = port;
            this._enableSSL = enableSSL;
            this._username = username;
            this._password = password;
        }
        
        // IEmailSender arayüzünden uygulanan SendEmailAsync metodu
        public Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            // SmtpClient sınıfı kullanılarak e-posta gönderme işlemi gerçekleştirilir.
            var client = new SmtpClient(this._host,this._port){
                Credentials = new NetworkCredential(_username,_password), // SMTP kimlik bilgileri
                EnableSsl = this._enableSSL // SSL kullanımı
            };

            // SmtpClient ile e-posta gönderme işlemi gerçekleştirilir.
            return client.SendMailAsync(
                // MailMessage sınıfı kullanılarak e-posta mesajı oluşturulur.
                new MailMessage(this._username,email,subject,htmlMessage){
                    IsBodyHtml = true // HTML formatında mesaj gönderilecek mi?
                }
            );
        }
    }
}